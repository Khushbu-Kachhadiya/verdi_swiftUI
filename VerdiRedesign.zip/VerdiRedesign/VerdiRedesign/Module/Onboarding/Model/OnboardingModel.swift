//
//  OnboardingModel.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI

//MARK: - OnboardingModel
struct OnboardingModel: Identifiable {
    let id: Int
    let image: Image
    let title: String
    let headline: String
}
