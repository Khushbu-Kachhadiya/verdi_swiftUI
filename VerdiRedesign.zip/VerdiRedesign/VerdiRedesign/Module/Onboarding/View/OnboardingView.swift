//
//  OnboardingView.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI
struct OnboardingView: View {
    //MARK: - Properties
    @EnvironmentObject private var rootManager: RootManager
    @State var selectedIndex: Int = 1
    
    //MARK: - Life cycle
    init() {
        UIPageControl.appearance().currentPageIndicatorTintColor = ThemeColors.appTextUIcolor
        UIPageControl.appearance().pageIndicatorTintColor = .gray.withAlphaComponent(0.5)
    }
    
    //MARK: - Body
    var body: some View {
        ZStack {
            Color.appTheme
                .ignoresSafeArea()
            
            VStack(spacing: 80.asDeviceHeight) {
                TabView(selection: $selectedIndex) {
                    ForEach(Globals.onBoardingData, id: \.id) { model in
                        OnbordingTabView(onboardingModel: model)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .customFrame(height: .very_large)
                
                Button {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        if selectedIndex < 3 {
                            selectedIndex = selectedIndex + 1
                        } else {
                            rootManager.currentRoot = .tabBar
                        }
                    }
                } label: {
                    Text(LocalizedStringKey(selectedIndex == 3 ? LocalizedStrings.Onboarding.done : LocalizedStrings.Onboarding.Further))
                        .foregroundColor(.appText)
                        .padding(.vertical, 10.asDeviceHeight)
                        .padding(.horizontal, 24.asDeviceWidth)
                        .customBorder(cornerRadius: 40.asDeviceHeight, color: .appGray, width: 1)
                }
            }
        }
    }
    //MARK: - Functions
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView()
    }
}
