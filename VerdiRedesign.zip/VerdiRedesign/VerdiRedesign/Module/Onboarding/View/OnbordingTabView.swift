//
//  OnbordingTabView.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI
struct OnbordingTabView: View {
    //MARK: - Properties
    let onboardingModel: OnboardingModel
    
    //MARK: - Life cycle
    var body: some View {
        VStack {
            onboardingModel.image
                .resizable()
                .scaledToFit()
                .customFrame(width: .large, height: .large)
                .padding(.bottom, .large)
            
            VStack(spacing: 8){
                Text(LocalizedStringKey(onboardingModel.title))
                    .font(.manrope(17, .bold))
                
                Text(LocalizedStringKey(onboardingModel.headline))
                    .font(.manrope(15))
                    .customFrame(width: .large, alignment: .center)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    //MARK: - Body
    
    //MARK: - Functions
}
struct OnbordingTabView_Previews: PreviewProvider {
    static var previews: some View {
        OnbordingTabView(onboardingModel: OnboardingModel(id: 1,
                                                          image: .appOnboarding1,
                                                          title: "Wichtige Ankündigungen",
                                                          headline: "Aktuelle und informative Inhalte, sorgfältig für Sie zusammengestellt.")
        )
        .padding(.horizontal, 20)
    }
}

