//
//  NewsFeedModel.swift
//  News Cenk
//
//  Created by APPLE on 21/12/23.
//

import Foundation


struct NewsFeedModel: Codable, Hashable {
    let date: String?
    let title: String?
    let link: String?
    let description: String?
    let image: String?
    let position: Int?
    
    init(date: String? = nil, title: String? = nil, link: String? = nil, description: String? = nil, image: String? = nil, position: Int? = nil) {
        self.date = date
        self.title = title
        self.link = link
        self.description = description
        self.image = image
        self.position = position
    }
}


