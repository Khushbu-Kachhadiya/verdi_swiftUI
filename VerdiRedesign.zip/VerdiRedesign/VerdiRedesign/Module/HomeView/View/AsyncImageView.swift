//
//  AsyncImageView.swift
//  News Cenk
//
//  Created by APPLE on 19/01/24.
//

import SwiftUI

struct AsyncImageView: View {
    @State var isImageLoading: Bool = true
    let url: URL
    var body: some View {
        AsyncImage(url: url, content: { phase in
            if let image = phase.image  {
                image
                    .resizable()
                    .scaledToFit()
                    .frame(alignment: .center)
                    .cornerRadius(8.asDeviceHeight)
            }else{
                Image("image_1_url")
                    .resizable()
                    .scaledToFit()
                    .frame(alignment: .center)
                    .cornerRadius(8.asDeviceHeight)
                    .foregroundColor(.gray)
                    .redacted(reason: isImageLoading ? .placeholder : [])
                    .animatePlaceholder(isLoading: $isImageLoading)
                    .onDisappear {
                        isImageLoading = false
                    }
            }
        })
    }
}

