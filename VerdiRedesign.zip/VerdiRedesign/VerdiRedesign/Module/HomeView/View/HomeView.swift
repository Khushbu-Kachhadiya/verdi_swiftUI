//
//  HomeView.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI

struct HomeView: View {
    //MARK: - Properties
    @StateObject var vm: HomeViewVM = HomeViewVM()
    //MARK: - Life cycle

    //MARK: - Body
    var body: some View {
        ZStack {
            Color.appTheme
                .ignoresSafeArea()
            
            VStack(alignment: .leading) {
                headerView
                    .padding(.horizontal, 16.asDeviceWidth)
                
                    newsFeed
            }
        }
        .handleOpenURLInApp()
    }
    
    private var headerView: some View{
        HStack {
            Image.appVerdiImage
                .resizable()
                .frame(width: 40.asDeviceWidth, height: 40.asDeviceWidth)
            
            Spacer()
            
            HStack(alignment: .center, spacing: 13) {
                Group{
                    Image.appFacebook
                        .resizable()
                        .onTapGesture {
                            vm.openSocialMediaApp(url: facebookURL, appStoreURL: facebookAppStoreURL)
                        }
                    
                    Image.appTwitter
                        .resizable()
                        .onTapGesture {
                            vm.openSocialMediaApp(url: twitterURL, appStoreURL: twitterAppStoreURL)
                        }
                    Image.appInstagram
                        .resizable()
                        .onTapGesture {
                            vm.openSocialMediaApp(url: instagramURL, appStoreURL: instagramAppstoreURL)
                        }
                }
                .scaledToFit()
                .customFrame(width: .small, height: .small)
            }
        }
        .padding(.vertical, 12)
    }
    
    private var newsFeed: some View{
        VStack() {
            HStack {
                Text(LocalizedStringKey(LocalizedStrings.Home.news))
                    .font(.manrope(24, .bold))
                    .foregroundColor(.appNavTitle)
                    .padding(.horizontal, .normal)
                
                Spacer()
            }
            .frame(maxWidth: .infinity)
            
            if !vm.failedTogetData{
                ScrollView(showsIndicators: false) {
                    VStack{
                        if vm.newsData.isEmpty {
                            ForEach(Globals.newsFeedData, id: \.self) { data in
                                newsFeed(data: data, isPlaceholder: true)
                                    .padding(.horizontal, .normal)
                                    .padding(.vertical, .small)
                                    .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
                            }
                            .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
                        }else{
                            ForEach(vm.newsData, id: \.self) { data in
                                if let url = URL(string: data.link ?? ""){
                                    Link(destination: url) {
                                        newsFeed(data: data, isPlaceholder: false)
                                            .padding(.horizontal, .normal)
                                            .padding(.vertical, .small)
                                            .frame(alignment: .leading)
                                            .multilineTextAlignment(.leading)
                                    }
                                }
                            }
                        }
                        
                        Spacer()
                    }
                }
                .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
            }else{
                warningView
                
                Spacer()
            }
        }
        .background(Color.clear)
       
    }
    
    @ViewBuilder
    private func newsFeed(data: NewsFeedModel, isPlaceholder: Bool) -> some View {
        VStack(alignment: .leading, spacing: 8.asDeviceHeight){
            if let url = URL(string: data.image ?? ""){
                AsyncImageView(url: url)
            }
            
            VStack(alignment: .leading, spacing: 8){
                Text(data.title ?? "")
                    .font(.manrope(16, .bold))
                    .foregroundColor(isPlaceholder ? .gray : .appNewsHeadline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
                    .animatePlaceholder(isLoading: $vm.isShimmering)
                
                
                Text(data.description ?? "")
                    .font(.manrope(14))
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(isPlaceholder ? .gray : .appNewsDiscription)
                    .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
                    .animatePlaceholder(isLoading: $vm.isShimmering)
                
                Text(data.date ?? "")
                    .font(.manrope(11))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .redacted(reason: vm.newsData.isEmpty ? .placeholder : [])
                    .animatePlaceholder(isLoading: $vm.isShimmering)
            }
        }
        .padding(.all, .small)
        .background(Color.appNewsCellBg)
        .cornerRadius(15.asDeviceHeight)
        .shadow(color: .black.opacity(0.3), radius: 2.asDeviceHeight)
    }
    
    private var warningView: some View{
        VStack{
            Image.appNodataImage
                .resizable()
            
            Text(LocalizedStringKey(LocalizedStrings.Home.warning))
                .font(.headline)
                .foregroundColor(.appNavTitle)
                .multilineTextAlignment(.center)
                .padding()
            
            Text(LocalizedStringKey(LocalizedStrings.Home.disclaimer))
                .font(.subheadline)
                .foregroundColor(.appNavTitle)
                .multilineTextAlignment(.center)
        }
        .frame(height: UIScreen.main.bounds.size.height * 0.5)
        .padding(.all, .small)
        .background(Color.appNewsCellBg)
        .cornerRadius(15.asDeviceHeight)
        .shadow(color: .black.opacity(0.3), radius: 2.asDeviceHeight)
        .padding()
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

