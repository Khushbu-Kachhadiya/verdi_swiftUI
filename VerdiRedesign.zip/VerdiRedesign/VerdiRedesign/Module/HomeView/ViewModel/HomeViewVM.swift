//
//  HomeViewVM.swift
//  News Cenk
//
//  Created by APPLE on 12/01/24.
//

import Foundation
import SwiftUI

@MainActor
final class HomeViewVM: ObservableObject {
    
    @Published var newsData: [NewsFeedModel] = []
    @Published var isShimmering: Bool = true
    @Published var failedTogetData: Bool = false
    @Published private var counter = 0
    var timer: Timer?
    
    private let networkManager: NetworkService
    
    init(networkManager: NetworkService = NetworkManager()) {
        self.networkManager = networkManager
        getNews()
        startTimer()
    }
    
    func getNews() {
        Task{
            do{
                let data = try await networkManager.getNews()
                let newsData = data.compactMap({ (key, value) in
                    return value
                })
                self.newsData = newsData.sorted{$0.position ?? 0 < $1.position ?? 0}
                stopTimer()
            }catch{
                print(error.localizedDescription)
            }
        }
    }
    
    
    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) {timer in
            DispatchQueue.main.async {
                self.counter += 1
                if self.counter == timeOut {
                    self.failedTogetData = true
                    self.stopTimer()
                }
            }
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
        isShimmering = false
    }
    
    func openSocialMediaApp(url: String, appStoreURL: String){
        let application = UIApplication.shared
        if  let appURL = URL(string: url),
            application.canOpenURL(appURL) {
            application.open(appURL)
        } else {
            // if app is not installed, then redairect them to App store
            if let appStoreURL = URL(string: appStoreURL) {
                UIApplication.shared.open(appStoreURL, options: [:], completionHandler: nil)
            }
        }
    }
}
