//
//  ContactModel.swift
//  News Cenk
//
//  Created by APPLE on 17/01/24.
//

import Foundation

struct ContactModel: Convertable{
    let name: String
    let email: String
    let ueberschrift: String
    let standort: String
    let betrieb: String
    let anliegen: String
    let ansprechpartner_email: String
    
    init(name: String, email: String, ueberschrift: String, standort: String, betrieb: String, anliegen: String, ansprechpartner_email: String = "cenk@yekta-it.de") {
        self.name = name
        self.email = email
        self.ueberschrift = "Aus der ver.di IKT App: \(ueberschrift)"
        self.standort = standort
        self.betrieb = betrieb
        self.anliegen = anliegen
        self.ansprechpartner_email = ansprechpartner_email
    }
}
