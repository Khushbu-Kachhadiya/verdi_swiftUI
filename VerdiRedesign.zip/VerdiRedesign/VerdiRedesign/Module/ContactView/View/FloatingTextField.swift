//
//  FloatingTextField.swift
//  News Cenk
//
//  Created by APPLE on 14/12/23.
//

import SwiftUI

struct FloatingTextField: View {
    //MARK: - Properties
    let textFieldHeight: CGFloat = 56.asDeviceHeight
    private let placeHolderText: String
    private let fieldType: FieldType
    @Binding var text: String
    @State private var isEditing = false
    @State private var isValid = false
    
    var shouldPlaceHolderMove: Bool {
        isEditing || (text.count != 0)
    }
    
    //MARK: - Life cycle
    public init(placeHolder: String,
                text: Binding<String>, fieldType: FieldType) {
        self._text = text
        self.placeHolderText = placeHolder
        self.fieldType = fieldType
    }
    
    //MARK: - Body
    var body: some View {
        ZStack(alignment: .leading) {
            TextField("", text: $text, onEditingChanged: { (edit) in
                isEditing = edit
            })
            .padding()
            .keyboardType(fieldType == .email ? .emailAddress : .default)
            .autocapitalization(fieldType == .email ? .none : .sentences)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(isEditing ? isValid ? Color.secondary : .red : Color.secondary, lineWidth: 1)
                    .frame(height: textFieldHeight)
            )
            .foregroundColor(.appNavTitle)
            .accentColor(Color.secondary)
            .font(.manrope(12))
            .animation(.linear, value: shouldPlaceHolderMove)
            .onChange(of: text) { newValue in
                switch fieldType{
                case .company, .name, .location, .subject:
                    isValid = newValue.isBlank ? false : true
                case .email:
                    isValid = newValue.isEmail ? true : false
                }
            }
            
            ///Floating Placeholder
            Text(LocalizedStringKey(placeHolderText))
                .foregroundColor(isEditing ? isValid ? Color.secondary : .red : Color.secondary)
                .padding(.horizontal, 8.asDeviceWidth)
                .background(shouldPlaceHolderMove ? Color.appNewsCellBg : Color(UIColor.clear))
                .font(.manrope(12))
                .padding(shouldPlaceHolderMove ?
                         EdgeInsets(top: 0, leading: 16.asDeviceWidth, bottom: textFieldHeight, trailing: 0) :
                            EdgeInsets(top: 0, leading: 16.asDeviceWidth, bottom: 0, trailing: 0))
                .scaleEffect(shouldPlaceHolderMove ? 1.0 : 1.2)
                .animation(.linear, value: shouldPlaceHolderMove)
        }
    }
    //MARK: - Functions

}

struct FloatingTextField_Previews: PreviewProvider {
    static var previews: some View {
        FloatingTextField(placeHolder: "Name", text: .constant(""), fieldType: .name)
    }
}
