//
//  NavigationHeaderView.swift
//  VerdiRedesign
//
//  Created by APPLE on 14/03/24.
//

import SwiftUI

struct NavigationHeaderView: View {
    let title: String
    var body: some View {
        ZStack {
            Color.appTabBg
                .ignoresSafeArea()
            navTitle
        }
        .frame(height: 64.asDeviceHeight)
    }
    
    private var navTitle: some View{
        HStack(alignment: .bottom){
            Text(LocalizedStringKey(title))
                .font(.manrope(24, .bold))
                .foregroundColor(.appNavTitle)
                .padding(.vertical)
            
            Spacer()
        }
        .padding(.horizontal, .normal)
    }
}

struct NavigationHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationHeaderView(title: "Title")
    }
}
