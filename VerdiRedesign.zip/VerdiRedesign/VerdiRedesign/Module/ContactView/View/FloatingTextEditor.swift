//
//  FloatingTextEditor.swift
//  News Cenk
//
//  Created by APPLE on 14/12/23.
//

import SwiftUI

struct FloatingTextEditor: View {
    //MARK: - Properties
    @Binding var text: String
    private let placeHolderText: String
    let textFieldHeight: CGFloat = 105.asDeviceHeight
    @Binding private var isEditing: Bool
    @State private var isValid = false
    var shouldPlaceHolderMove: Bool {
        isEditing || (text.count != 0)
    }
    //MARK: - Life cycle
    public init(placeHolder: String,
                text: Binding<String>, isEditing:Binding<Bool>) {
        self._text = text
        self.placeHolderText = placeHolder
        self._isEditing = isEditing
    }

    //MARK: - Body
    var body: some View {
        ZStack(alignment: .leading) {
            TextEditor(text: $text)
                .frame(height: textFieldHeight)
                .foregroundColor(.appNavTitle)
                .font(.manrope(12))
                .scrollContentBackground(.hidden)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(isEditing ? isValid ? Color.secondary : .red : Color.secondary, lineWidth: 1)
                        .frame(height: textFieldHeight)
                )
                .animation(.linear, value: shouldPlaceHolderMove)
                .onChange(of: text, perform: { newValue in
                    isValid = newValue.isBlank ? false : true
                })
                .onTapGesture {
                    isEditing = true
                }

            //Floating Placeholder
            Text(LocalizedStringKey(placeHolderText))
                .foregroundColor(isEditing ? isValid ? Color.secondary : .red : Color.secondary)
                .padding(.horizontal, 8.asDeviceWidth)
                .background(shouldPlaceHolderMove ? Color.appNewsCellBg : Color(UIColor.clear))
                .font(.manrope(12))
                .padding(shouldPlaceHolderMove ?
                         EdgeInsets(top: 0, leading: 15, bottom: textFieldHeight, trailing: 0) :
                            EdgeInsets(top: 0, leading: 15, bottom: 0, trailing: 0))
                .scaleEffect(shouldPlaceHolderMove ? 1.0 : 1.2)
                .animation(.linear, value: shouldPlaceHolderMove)
        }

    }
    //MARK: - Functions
}


struct FloatingTextEditor_Previews: PreviewProvider {
    static var previews: some View {
        FloatingTextEditor(placeHolder: "Text", text: .constant(""), isEditing: .constant(false))
    }
}

