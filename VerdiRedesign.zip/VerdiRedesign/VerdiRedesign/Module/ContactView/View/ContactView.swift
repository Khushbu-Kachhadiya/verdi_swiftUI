//
//  ContactView.swift
//  News Cenk
//
//  Created by APPLE on 13/12/23.
//

import SwiftUI

struct ContactView: View {
    //MARK: - Properties
    @StateObject var vm: ContactViewVM = ContactViewVM()
    @FocusState private var focusedField: FocusedField?
    
    var isSendButtonEnabled: Bool {
        return !vm.company.isBlank && !vm.location.isBlank && !vm.name.isBlank && !vm.email.isBlank && !vm.text.isBlank && !vm.subject.isBlank
    }
    
    enum FocusedField: String {
        case company, location, name, email, text, subject
    }
    
    //MARK: - Life cycle
    
    //MARK: - Body
    
    var body: some View {
        ZStack(alignment: .top){
            Color.appTheme
                .ignoresSafeArea()

            VStack{
                
                NavigationHeaderView(title: LocalizedStrings.Contact.title)

                ScrollView(showsIndicators: false){
                    VStack{
                        userInputSection
                        
                        sendButton
                    }
                    .keyboardAdaptive()
                }
                
            }
        }
        .customAlert(isPresented: $vm.showAlert, title: vm.alertTitle, alertMessage: vm.alertMessage)
        .onTapGesture {
            hideKeyboard()
        }
        .onChange(of: vm.showAlert) { newValue in
            if newValue == false{
                vm.company = ""
                vm.location = ""
                vm.name = ""
                vm.email = ""
                vm.text = ""
                vm.subject = ""
                vm.typedCharacters = 0
                focusedField = nil
            }
        }
    }
    
    private var userInputSection: some View{
        VStack(spacing: 32.asDeviceHeight){
            VStack(spacing: 20.asDeviceHeight){
                FloatingTextField(placeHolder: LocalizedStrings.Contact.mycompany, text: $vm.company, fieldType: .company)
                    .customFrame(height: .textFieldHeight)
                    .focused($focusedField, equals: .company)
                    .onTapGesture {
                        focusedField = .company
                    }
                
                FloatingTextField(placeHolder: LocalizedStrings.Contact.location, text: $vm.location, fieldType: .location)
                    .customFrame(height: .textFieldHeight)
                    .focused($focusedField, equals: .location)
                    .onTapGesture {
                        focusedField = .location
                    }
            }
            .padding(.horizontal, 10.asDeviceWidth)
            
            VStack(spacing: 20.asDeviceHeight){
                FloatingTextField(placeHolder: LocalizedStrings.Contact.name, text: $vm.name, fieldType: .name)
                    .customFrame(height: .textFieldHeight)
                    .focused($focusedField, equals: .name)
                    .onTapGesture {
                        focusedField = .name
                    }
                
                FloatingTextField(placeHolder: LocalizedStrings.Contact.mail, text: $vm.email, fieldType: .email)
                    .customFrame(height: .textFieldHeight)
                    .focused($focusedField, equals: .email)
                    .onTapGesture {
                        focusedField = .email
                    }
            }
            .padding(.horizontal, 10.asDeviceWidth)
            
            FloatingTextField(placeHolder: LocalizedStrings.Contact.subject, text: $vm.subject, fieldType: .subject)
                .customFrame(height: .textFieldHeight)
                .focused($focusedField, equals: .subject)
                .onTapGesture {
                    focusedField = .subject
                }
                .padding(.horizontal, 10.asDeviceWidth)
            
            VStack(spacing: 0){
                FloatingTextEditor(placeHolder: LocalizedStrings.Contact.text, text: $vm.text, isEditing: .constant(focusedField == .text ? true : false))
                    .focused($focusedField, equals: .text)
                    .frame(height: 105.asDeviceHeight)
                    .onTapGesture {
                        focusedField = .text
                    }
                    .onChange(of: vm.text) { result in
                        vm.typedCharacters = vm.text.count
                        vm.text = String(vm.text.prefix(500))
                    }
                
                HStack(alignment: .top){
                    Spacer()
                    Text("\(vm.typedCharacters)/500")
                        .font(.manrope(12))
                        .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal, 10.asDeviceWidth)
        }
        .padding(.vertical)
        .background(Color.appNewsCellBg)
        .cornerRadius(10.asDeviceHeight)
        .shadow(color: .black.opacity(0.3), radius: 3)
        .padding(.horizontal, 17.asDeviceWidth)
        .padding(.top, .normal)
        .frame(maxHeight: 575.asDeviceHeight)
    }
    
    private var sendButton: some View{
        Button {
            guard vm.email.isEmail else {
                focusedField = .email
                return
            }
            let data = ContactModel(name: vm.name, email: vm.email, ueberschrift: vm.subject, standort: vm.location, betrieb: vm.company, anliegen: vm.text)
            
            vm.sendContactData(data: data)
        } label: {
            Text(LocalizedStringKey(LocalizedStrings.Contact.send))
                .font(.manrope(14))
                .frame(width: 100.asDeviceWidth, height: 40.asDeviceHeight)
                .foregroundColor(isSendButtonEnabled ? .white : .gray)
                .background( isSendButtonEnabled ? Color.appGlobBG : Color.diabledButtonBG)
                .cornerRadius(20.asDeviceHeight)
        }
        .disabled(!isSendButtonEnabled)
        .padding(.all, 24.asDeviceHeight)
    }
    
    //MARK: - Functions
}

struct ContactView_Previews: PreviewProvider {
    static var previews: some View {
        ContactView()
    }
}

