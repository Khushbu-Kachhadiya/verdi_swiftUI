//
//  ContactViewVM.swift
//  News Cenk
//
//  Created by APPLE on 17/01/24.
//

import Foundation

@MainActor
final class ContactViewVM: ObservableObject{
    
    @Published var company: String = ""
    @Published var location: String = ""
    @Published var name: String = ""
    @Published var email: String = ""
    @Published var text: String = ""
    @Published var typedCharacters: Int = 0
    @Published var showAlert: Bool = false
    @Published var alertMessage: String = ""
    @Published var alertTitle: String = ""
    @Published var subject: String = ""
    private let networkManager: NetworkService
    
    init(networkManager: NetworkService = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func sendContactData(data: ContactModel){
        Task{
            do{
                try await networkManager.sendContactData(data: data)
                alertMessage = LocalizedStrings.CustomPopup.discription
                alertTitle = LocalizedStrings.CustomPopup.confirmation
                showAlert = true
            } catch let error as APIError {
                alertMessage = error.description
                alertTitle = "Alert"
            } catch {
                alertMessage = "Something went wrong please try again"
                alertTitle = "Alert"
            }
        }
    }
}
