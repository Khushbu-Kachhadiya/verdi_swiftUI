//
//  CustomPopupView.swift
//  News Cenk
//
//  Created by APPLE on 26/12/23.
//

import SwiftUI

struct CustomPopupView: View {
    @Binding var isPresented: Bool
    let title: String
    let alertMessage: String
    var body: some View {
        VStack(alignment: .center, spacing: 16.asDeviceHeight){
            Image.appPopuoIcon
                .customFrame(width: .small, height: .small)
            
            Text(LocalizedStringKey(title))
                .foregroundColor(.appNavTitle)
                .font(.manrope(24, .bold))
            
            Text(LocalizedStringKey(alertMessage))
                .font(.manrope(14))
                .foregroundColor(.appPopupText)
                .frame(width: 264.asDeviceWidth)
                .frame(minHeight: 60.asDeviceHeight)
                .multilineTextAlignment(.leading)
            
            HStack{
                Spacer()
                Text("Ok")
                    .font(.manrope(14, .semibold))
                    .foregroundColor(.appGlobBG)
                    .padding(.trailing, 34)
                    .onTapGesture {
                        isPresented = false
                    }
            }
        }
        .padding(24.asDeviceHeight)
        .frame(width: 312.asDeviceWidth)
        .frame(minHeight: 260.asDeviceHeight)
        .background(
            RoundedRectangle(cornerRadius: 28)
                .fill(Color.appTheme)
        )
    }
}

struct CustomPopupView_Previews: PreviewProvider {
    static var previews: some View {
        CustomPopupView(isPresented: .constant(true), title: "Bestätigung", alertMessage: "Ihre Nachricht wurde erfolgreich übermittelt, wir werden uns bei Ihnen melden. Ihre Nachricht wurde erfolgreich übermittelt, wir werden uns bei Ihnen melden")
    }
}
