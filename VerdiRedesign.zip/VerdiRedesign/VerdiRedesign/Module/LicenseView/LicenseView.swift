//
//  LicenseView.swift
//  VerdiRedesign
//
//  Created by APPLE on 22/01/24.
//

import SwiftUI
import AcknowList

struct LicenseView: View {
    
    init() {
        UINavigationBar.appearance().tintColor = .black    }
    
    var body: some View {
        ZStack{
            Color.appTheme
                .ignoresSafeArea()
            
            if let url = Bundle.main.url(forResource: "Package", withExtension: "resolved"),
               let data = try? Data(contentsOf: url),
               let acknowList = try? AcknowPackageDecoder().decode(from: data) {
                ScrollView{
                    VStack(spacing: 0){
                        ForEach (acknowList.acknowledgements) { acknowledgement in
                            if let destination = acknowledgement.repository {
                                Link(destination: destination) {
                                    Text(acknowledgement.title)
                                        .foregroundColor(.appNavTitle)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .font(.manrope(14, .semibold))
                                }
                                .padding()
                                
                                Divider()
                            }
                        }
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color.appNewsCellBg)
                    )
                    .padding()
                }
            }
        }
    }
    
}

struct LicenseView_Previews: PreviewProvider {
    static var previews: some View {
        LicenseView()
    }
}
