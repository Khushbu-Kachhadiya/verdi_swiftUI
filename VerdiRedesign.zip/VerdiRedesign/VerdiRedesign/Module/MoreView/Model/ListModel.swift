//
//  ListModel.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import Foundation

struct ListModel: Identifiable, Hashable{
    var id: Int
    var title: String?
    var systemImage: String?
    var image: String?
    var link: String?
    var description1: String?
    var description2: String?
    var webLink: String?
}


let data = [
    ListModel(id: 1, title: LocalizedStrings.More.My_ver_di, systemImage: "globe", link: Meine_ver_diLink),
    ListModel(id: 2, title: LocalizedStrings.More.ver_di_IKT_NRW, systemImage: "globe", link: ver_di_IKT_NRW),
    ListModel(id: 3, title: LocalizedStrings.More.become_member, image: "app.Icon.person", link: become_member),
    ListModel(id: 4, title: LocalizedStrings.More.Tec_implementation, image: "app.Icon.mobile",
              description1: LocalizedStrings.Imprint.Tec_implementation_discription,
              webLink: moreViewLink)
]


let legalDataToDisplay = [
    ListModel(id: 1, title: LocalizedStrings.More.imprint, image: "app.Icon.pixelarticons", link: imprint),
    ListModel(id: 2, title: LocalizedStrings.More.data_protection, image: "app.Icon.shield", link: moreViewLink)
]
