//
//  ImprintView.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import SwiftUI

struct TechnicalImplementationView: View {
    //MARK: - Properties
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject private var rootManager: RootManager
    let data: ListModel
    //MARK: - Life cycle
    
    //MARK: - Body
    
    var body: some View {
        NavigationView{
            ZStack {
                Color.appTheme
                    .ignoresSafeArea()
                
                VStack{
                    navTitle
                    
                    textBlock
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    
                    Spacer()
                    
                    NavigationLink {
                        LicenseView()
                    } label: {
                        Text(LocalizedStrings.Imprint.Open_source_licenses)
                            .font(.manrope(14))
                            .underline()
                            .foregroundColor(.appGlobBG)
                            .padding()
                    }
                    .padding()
                }
                .edgesIgnoringSafeArea(.top)
            }
            .handleOpenURLInApp()
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    //MARK: - Functions
    
    private var navTitle: some View{
        Color.appTabBg
            .frame(height: 156.asDeviceHeight)
            .frame(maxWidth: .infinity, alignment: .top)
            .overlay(alignment: .bottomLeading){
                VStack(alignment: .leading, spacing: 16){
                    HStack{
                        Image(systemName: "arrow.left")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(.appNavTitle)
                            .customFrame(width: .small, height: .small)
                            .onTapGesture {
                                rootManager.selectedTab = 2
                                rootManager.currentRoot = .tabBar
                            }
                        Spacer()
                    }
                    
                    Text(LocalizedStringKey(data.title ?? ""))
                        .font(.manrope(24, .semibold))
                        .foregroundColor(.appNavTitle)
                }
                .padding(.leading, .normal)
                .padding(.bottom, .medium)
            }
    }
    
    private var textBlock: some View{
        VStack(alignment: .leading, spacing: 18.asDeviceHeight){
            Text(LocalizedStringKey(data.description1 ?? ""))
            .font(.manrope(14))
            .foregroundColor(.appNavTitle)
            .lineSpacing(5)
            
            if data.description2 != nil{
                Text(LocalizedStringKey(data.description2 ?? ""))
                    .font(.manrope(14))
                    .foregroundColor(.appNavTitle)
                    .lineSpacing(5)
            }
            
            if let link = URL(string: data.webLink ?? ""){
                Link(destination: link) {
                    HStack(alignment: .bottom){
                        Text(LocalizedStrings.Imprint.webLink)
                            .font(.manrope(14))
                            .underline()
                            .foregroundColor(.appGlobBG)
                        
                        Spacer()
                        
                        Image.appIconVector
                            .resizable()
                            .frame(width: 18.asDeviceWidth, height: 18.asDeviceWidth)
                    }
                    
                }
                .contentShape(Rectangle())
            }
        }
        .padding(.vertical, 16.asDeviceHeight)
        .padding(.horizontal, 16.asDeviceWidth)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.appNewsCellBg)
        )
        .padding(.all, .normal)
    }
}

struct ImprintView_Previews: PreviewProvider {
    static var previews: some View {
        TechnicalImplementationView(data: data[2])
    }
}


