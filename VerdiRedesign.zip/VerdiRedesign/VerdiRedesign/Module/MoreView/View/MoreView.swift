//
//  MoreView.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import SwiftUI
import AcknowList

struct MoreView: View {
    //MARK: - Properties
    @State var generalData = data
    @State var legalData = legalDataToDisplay
    @EnvironmentObject private var rootManager: RootManager
    //MARK: - Life cycle
    
    //MARK: - Body
    var body: some View {
        NavigationView{
            ZStack {
                Color.appTheme
                    .ignoresSafeArea()
                
                VStack{
                    NavigationHeaderView(title: LocalizedStrings.More.more)
                    
                    MoreListView(listArr: generalData, title: LocalizedStrings.More.genaral)
                    
                    MoreListView(listArr: legalData, title: LocalizedStrings.More.Legal)
                    
                    Spacer()
                }
            }
        }
        .handleOpenURLInApp()
        .toolbar(.hidden, for: .tabBar)
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
    }
    
    @ViewBuilder
    func MoreListView(listArr: [ListModel], title: String) -> some View{
        VStack(alignment: .leading, spacing: 0){
            Text(LocalizedStringKey(title))
                .font(.manrope(14, .semibold))
                .foregroundColor(.appNavTitle)
                .padding(.bottom, 8.asDeviceHeight)
            
            VStack(spacing: 16.asDeviceHeight) {
                ForEach(listArr, id:\.self){ data in
                    if let url = URL(string: data.link ?? ""){
                        Link(destination: url) {
                            MoreListRow(data: data)
                                .contentShape(Rectangle())
                        }
                    }else{
                        MoreListRow(data: data)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                rootManager.currentRoot = .imprint(data: data)
                            }
                    }
                }
            }
            .padding(.all, .normal)
            .background(
                RoundedRectangle(cornerRadius: 16.asDeviceHeight)
                    .fill(Color.appNewsCellBg)
            )
        }
        .padding(.all, 16.asDeviceHeight)
    }
    
    @ViewBuilder
    func MoreListRow(data: ListModel) -> some View {
        HStack(spacing: 24.asDeviceHeight){
            if let imageName = data.image{
                Image(imageName)
                    .resizable()
                    .foregroundColor(.appPersonIconColor)
                    .frame(width: 24.asDeviceWidth, height: 24.asDeviceWidth)
            } else{
                Image(systemName: data.systemImage ?? "")
                    .resizable()
                    .frame(width: 24.asDeviceWidth, height: 24.asDeviceWidth)
                    .foregroundColor(.appGlobBG)
            }
            
            Text(LocalizedStringKey(data.title ?? ""))
                .foregroundColor(.appNavTitle)
                .font(.manrope(14, .semibold))
            
            Spacer()
            
            if let _ = data.link{
                Image.appIconVector
                    .resizable()
                    .frame(width: 18.asDeviceWidth, height: 18.asDeviceWidth)
            }
        }
        .customFrame(height: .medium)
    }
    //MARK: - Functions
}

struct MoreView_Previews: PreviewProvider {
    static var previews: some View {
        MoreView()
    }
}
