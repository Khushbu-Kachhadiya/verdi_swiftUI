//
//  CustomTabbarScreenView.swift
//  Squeezee SwiftUI
//
//  Created by AKASH on 12/08/23.
//

import SwiftUI

enum TabItem: Int, CaseIterable {
    case home = 0
    case contact
    case settings
    
    var image: Image {
        switch self {
        case .home:
            return Image.appHomeTab
        case .contact:
            return Image.appContactTab
        case .settings:
            return Image.appSettingsTab
        }
    }
    
    var tabName: String {
        switch self {
        case .home:
            return LocalizedStrings.Tabbar.tab1
        case .contact:
            return LocalizedStrings.Tabbar.tab2
        case .settings:
            return LocalizedStrings.Tabbar.tab3
        }
    }
}

struct CustomTabbarScreenView: View {
    @EnvironmentObject private var rootManager: RootManager
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $rootManager.selectedTab) {
                HomeView()
                    .tag(0)
                
                ContactView()
                    .tag(1)
                
                MoreView()
                    .tag(2)
            }
            
            ZStack {
                HStack(spacing: 32.asDeviceHeight){
                    ForEach(TabItem.allCases, id: \.self) { item in
                        Button {
                            rootManager.selectedTab = item.rawValue
                        } label: {
                            CustomTabItem(image: item.image, isActive: rootManager.selectedTab == item.rawValue, tabName: item.tabName)
                        }
                    }
                }
                
            }
            .customFrame(height: .normal)
            .padding(.horizontal, .large)
            .padding(.bottom, .normal)
            .background(Color.appTabBg)
        }
        .ignoresSafeArea()
        .onAppear {
            UserDefaultsManager.shared.saveUserOnboardingStatus(status: false)
        }
    }
}

extension CustomTabbarScreenView {
    func CustomTabItem(image: Image, isActive: Bool, tabName: String) -> some View {
        HStack {
            Spacer()
            VStack{
                if isActive {
                    image
                        .resizable()
                        .renderingMode(.template)
                        .scaledToFit()
                        .customFrame(width: .small, height: .small)
                        .tint(.appText)
                        .padding(.vertical, .small)
                        .padding(.horizontal, .medium)
                        .background(Color.appText.opacity(0.1))
                        .clipShape(Capsule())
                } else {
                    image
                        .resizable()
                        .renderingMode(.template)
                        .scaledToFit()
                        .customFrame(width: .small, height: .small)
                        .tint(.appGray)
                }
                
                Text(LocalizedStringKey(tabName))
                    .font(.manrope(12))
                    .foregroundColor(isActive ? .appText : .appGray)
            }
            
            Spacer()
        }
    }
}

struct CustomTabbarScreenView_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabbarScreenView()
            .previewLayout(.sizeThatFits)
    }
}
