//
//  RootManager.swift
//  SwiftUIDemo
//
//  Created by iOS Developer on 11/12/23.
//

import Foundation

final class RootManager: ObservableObject {
    //MARK: - Properties
    @Published var currentRoot: Root = .home
    @Published var selectedTab: Int = 0
    init(){
        currentRoot = UserDefaultsManager.shared.isFirstTimeUser() ? .onboarding : .tabBar
    }
    
    //MARK: - Root
    enum Root {
        case onboarding
        case home
        case tabBar
        case imprint(data: ListModel)
    }
}
