//
//  UserDefaultsManager.swift
//  News Cenk
//
//  Created by APPLE on 15/01/24.
//

import Foundation


class UserDefaultsManager: ObservableObject{
    
    static let shared: UserDefaultsManager = UserDefaultsManager()
    private init() {}
    
    func saveUserOnboardingStatus(status: Bool) {
        UserDefaults.standard.set(status, forKey: "isFirstTimeUser")
    }
    
    func isFirstTimeUser() -> Bool{
        UserDefaults.standard.value(forKey: "isFirstTimeUser") as? Bool ?? true
    }
    
    func saveFcmToken(token: String) {
        UserDefaults.standard.set(token, forKey: "fcmToken")
    }
    
    func getFcmToken() -> String {
        UserDefaults.standard.value(forKey: "fcmToken") as? String ?? ""
    }
}
