//
//  CustomAlert.swift
//  News Cenk
//
//  Created by APPLE on 16/01/24.
//

import SwiftUI

struct CustomAlertModifier: ViewModifier{
    @Binding var isPresented: Bool
    var title: String
    var alertMessage: String

       func body(content: Content) -> some View {
           content
               .overlay(alignment: .center, content: {
                   if isPresented {
                       VStack(alignment: .center){
                           CustomPopupView(isPresented: $isPresented, title: title, alertMessage: alertMessage)
                       }
                       .frame(maxWidth: .infinity, maxHeight: .infinity)
                       .background(Color.black.opacity(0.2))
                   }
               })
               
       }
}


extension View {
    func customAlert(isPresented: Binding<Bool>, title: String, alertMessage: String) -> some View {
        self.modifier(CustomAlertModifier(isPresented: isPresented, title: title, alertMessage: alertMessage))
    }
}
