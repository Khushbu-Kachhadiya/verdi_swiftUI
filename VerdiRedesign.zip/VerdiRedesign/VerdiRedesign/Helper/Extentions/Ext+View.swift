//
//  Ext+View.swift
//  SwiftUIDemo
//
//  Created by iOS Developer on 11/12/23.
//

import SwiftUI

extension View {    
    /// Apply a custom border to the view.
    /// - Parameters:
    ///   - color: The color of the border.
    ///   - width: The width of the border.
    func customBorder(cornerRadius: CGFloat, color: Color, width: CGFloat) -> some View {
        self
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius.asDeviceHeight)
                    .stroke(color, lineWidth: width)
            )
    }
    
    func padding(_ edges: Edge.Set = .all, _ paddingType: PaddingType) -> some View {
        padding(edges, paddingType.value)
    }
    
    func customFrame(width: FrameType? = nil, height: FrameType? = nil, alignment: Alignment = .center) -> some View {
        frame(width: width?.value.asDeviceWidth, height: height?.value.asDeviceHeight, alignment: alignment)
    }
    
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
    
}

