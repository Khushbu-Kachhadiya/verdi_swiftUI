//
//  Ext+Font.swift
//  SwiftUIDemo
//
//  Created by iOS Developer on 11/12/23.
//

import SwiftUI

extension Font {
    static func manrope(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Self {
        switch weight {
        case .bold: return .custom("Manrope-Bold", size: size.asDeviceWidth)
        case .heavy: return .custom("Manrope-ExtraBold", size: size.asDeviceWidth)
        case .light: return .custom("Manrope-Light", size: size.asDeviceWidth)
        case .medium: return .custom("Manrope-Medium", size: size.asDeviceWidth)
        case .regular: return .custom("Manrope-Regular", size: size.asDeviceWidth)
        case .semibold: return .custom("Manrope-SemiBold", size: size.asDeviceWidth)
        case .ultraLight: return .custom("Manrope-ExtraLight", size: size.asDeviceWidth)
        default: fatalError("\(Font.self) \(weight) is not yet supported")
        }
    }
}
