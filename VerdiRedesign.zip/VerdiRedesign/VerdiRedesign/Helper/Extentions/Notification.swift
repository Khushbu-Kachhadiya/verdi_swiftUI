//
//  Notification.swift
//  News Cenk
//
//  Created by APPLE on 17/01/24.
//

import SwiftUI

extension Notification {
    var keyboardHeight: CGFloat {
        return (userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect)?.height ?? 0
    }
}
