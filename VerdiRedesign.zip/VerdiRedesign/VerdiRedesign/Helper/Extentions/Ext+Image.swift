//
//  Ext+Image.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI

extension Image {
    static let appSplash = AppImages.appSplash
    static let appOnboarding1 = AppImages.appOnboarding1
    static let appOnboarding2 = AppImages.appOnboarding2
    static let appOnboarding3 = AppImages.appOnboarding3
    static let appHomeTab = AppImages.appHomeTab
    static let appHomeTabSelected = AppImages.appHomeTabSelected
    static let appContactTab = AppImages.appContactTab
    static let appContactTabSelected = AppImages.appContactTabSelected
    static let appSettingsTab = AppImages.appSettingsTab
    static let appSettingsTabSelected = AppImages.appSettingsTabSelected
    static let appFacebook = AppImages.appFacebook
    static let appTwitter = AppImages.appTwitter
    static let appInstagram = AppImages.appInstagram
    static let appDemoImage = AppImages.appDemoImage
    static let appIconflag = AppImages.appIconflag
    static let appIconVector = AppImages.appIconVector
    static let appIconShield = AppImages.appIconShield
    static let appIconPerson = AppImages.appIconPerson
    static let appIconMobile = AppImages.appIconMobile
    static let appArrowBack = AppImages.appArrowBack
    static let appPopuoIcon = AppImages.appPopuoIcon
    static let appNodataImage = AppImages.appNodataImage
    static let appVerdiImage = AppImages.appVerdiImage
}
