//
//  Ext+Color.swift
//  News Cenk
//
//  Created by APPLE on 12/12/23.
//

import SwiftUI

extension Color {
    static let appTheme = ThemeColors.appTheme
    static let appText = ThemeColors.appText
    static let appGray = ThemeColors.appGray
    static let appTabBg = ThemeColors.appTabBg
    static let appNavTitle = ThemeColors.appNavTitle
    static let appNewsHeadline = ThemeColors.appNewsHeadline
    static let appNewsDiscription = ThemeColors.appNewsDiscription
    static let appNewsCellBg = ThemeColors.appNewsCellBg
    static let appBoarder = ThemeColors.appBoarder
    static let appPopupText = ThemeColors.appPopupText
    static let appGlobBG = ThemeColors.appGlobBG
    static let diabledButtonBG = ThemeColors.diabledButtonBG
    static let appDisabledText =  ThemeColors.appDisabledText
    static let appPersonIconColor = ThemeColors.appPersonIconColor
}
