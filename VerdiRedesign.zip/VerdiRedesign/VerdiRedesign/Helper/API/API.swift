//
//  API.swift
//  SwiftUIBoilerPlate
//
//  Created by AKASH BOGHANI on 11/12/23.
//

import Foundation
import Moya

enum API {
    case getNews
    case contact(data: ContactModel)
}

extension API: TargetType {
    var baseURL: URL {
        return URL(string: "https://www.verdi-tk-it-nrw-app.de")!
    }
    
    var path: String {
        switch self {
            
        case .getNews:
            return "/verdi-news/news2.json"
        case .contact:
            return "/anfrage.php"
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .getNews:
            return .get
        case .contact:
            return .post
        }
    }
    
    var task: Task {
        switch self {
        case .getNews:
            return .requestPlain
        case .contact(let contactModel):
            let params = contactModel.convertToDict() ?? [:]
            var multipartData = [MultipartFormData]()
            for (key, value) in params {
                let parameter = value as? String ?? ""
                let formData = MultipartFormData(provider: .data(parameter.data(using: .utf8)!), name: key)
                multipartData.append(formData)
            }
            return .uploadMultipart(multipartData)
        }
    }
    
    var headers: [String : String]? {
        switch self {
        case .getNews:
            return ["Content-Type": "application/json"]
        case .contact:
            return ["Content-Type": "multipart/form-data"]
        }
    }
}
