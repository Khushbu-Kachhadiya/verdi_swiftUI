//
//  LocalizedStrings.swift
//  News Cenk
//
//  Created by APPLE on 19/01/24.
//

import Foundation

struct LocalizedStrings{
    struct Onboarding{
        static let taglinea1 = "OB_taglinea1"
        static let discription1 = "OB_discription1"
        static let taglinea2 = "OB_taglinea2"
        static let discription2 = "OB_discription2"
        static let taglinea3 = "OB_taglinea3"
        static let discription3 = "OB_discription3"
        static let Further = "Further"
        static let done = "Done"
    }
    
    struct Tabbar{
        static let tab1 = "tab1_title"
        static let tab2 = "tab2_title"
        static let tab3 = "tab3_title"
    }
    
    struct Home{
        static let news = "News"
        static let warning = "warning"
        static let disclaimer = "disclaimer"
        static let created = "created_an"
        static let hour = "hour_ago"
    }
    
    struct Contact{
        static let title = "contact_title"
        static let mycompany = "My_company"
        static let location = "my_location"
        static let name = "Name"
        static let mail = "E-Mail"
        static let text = "Text"
        static let send = "Send"
        static let subject = "Subject"
    }
    
    struct CustomPopup{
        static let confirmation = "Confirmation"
        static let discription = "popup_discription"
        static let ok = "ok"
    }
    
    struct More{
        static let more = "more"
        static let genaral = "genaral"
        static let ver_di_IKT_NRW = "ver.di_IKT_NRW"
        static let My_ver_di = "My_ver.di"
        static let become_member = "become_member"
        static let Tec_implementation = "Tec_implementation"
        static let Legal = "Legal"
        static let imprint = "imprint"
        static let data_protection = "data_protection"
    }
    
    struct Imprint{
        static let Tec_implementation_discription = "Tec_implementation_discription"
        static let webLink = "Yekta IT GmbH"
        static let Open_source_licenses = "Open Source Licenses"
    }
}
