//
//  AppImages.swift
//  News Cenk
//
//  Created by APPLE on 19/01/24.
//

import SwiftUI

struct AppImages{
    static let appSplash = Image("app.splash")
    static let appOnboarding1 = Image("app.onboarding.1")
    static let appOnboarding2 = Image("app.onboarding.2")
    static let appOnboarding3 = Image("app.onboarding.3")
    static let appHomeTab = Image("app.homeTab")
    static let appHomeTabSelected = Image("app.homeTab.selected")
    static let appContactTab = Image("app.contactTab")
    static let appContactTabSelected = Image("app.contactTab.selected")
    static let appSettingsTab = Image("app.settingsTab")
    static let appSettingsTabSelected = Image("app.settingsTab.selected")
    static let appFacebook = Image("app.facebook")
    static let appTwitter = Image("app.twitter")
    static let appInstagram = Image("app.instagram")
    static let appDemoImage = Image("app.demoImage")
    static let appIconflag = Image("app.Icon.flag")
    static let appIconVector = Image("app.Icon.Vector")
    static let appIconShield = Image("app.Icon.shield")
    static let appIconPerson = Image("app.Icon.person")
    static let appIconMobile = Image("app.Icon.mobile")
    static let appArrowBack = Image("app.arrow_back")
    static let appPopuoIcon = Image("app.popuo.Icon")
    static let appNodataImage = Image("app.nodata")
    static let appVerdiImage = Image("app.ver.di")
}
