//
//  ThemeColors.swift
//  News Cenk
//
//  Created by APPLE on 19/01/24.
//

import SwiftUI

struct ThemeColors{
    static let appTheme = Color("app.theme")
    static let appTextUIcolor = UIColor(named: "app.text")
    static let appText = Color("app.text")
    static let appGray = Color("app.gray")
    static let appTabBg = Color("app.tab.bg")
    static let appNavTitle = Color("app.navTitle")
    static let appNewsHeadline = Color("app.newsHeadline")
    static let appNewsDiscription = Color("app.newsDiscription")
    static let appNewsCellBg = Color("app.newsCell.bg")
    static let appBoarder = Color("app.boarder")
    static let appPopupText = Color("app.PopupText")
    static let appGlobBG = Color("app.globBG")
    static let diabledButtonBG = Color("app.diabledButtonBG")
    static let appDisabledText =  Color("app.DisabledText")
    static let appPersonIconColor = Color("app.personIcon")
}
