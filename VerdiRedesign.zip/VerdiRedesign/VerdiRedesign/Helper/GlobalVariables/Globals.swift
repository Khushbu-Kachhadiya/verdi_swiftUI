//
//  Globals.swift
//  Squeezee
//
//  Created by iOS Developer on 19/09/23.
//

import Foundation
import UIKit
import Combine

//MARK: - Globals
enum Globals {
    //MARK: - Values With Decive Size
    static var onBoardingData: [OnboardingModel] {
        return [
            OnboardingModel(id: 1, image: .appOnboarding1, title: LocalizedStrings.Onboarding.taglinea1, headline: LocalizedStrings.Onboarding.discription1),
            OnboardingModel(id: 2, image: .appOnboarding2, title: LocalizedStrings.Onboarding.taglinea2, headline: LocalizedStrings.Onboarding.discription2),
            OnboardingModel(id: 3, image: .appOnboarding3, title: LocalizedStrings.Onboarding.taglinea3, headline: LocalizedStrings.Onboarding.discription3)
        ]
    }
    
    static let newsFeedData = [
        NewsFeedModel(date: "01.01.2023",
                      title: "Hier engagieren wir uns für Sie",
                      link: "entry_1_url",
                      description: "Die geplante Schließung von \("DuMont Druck") und die damit verbundene Entlassung und Unsicherheit...",
                      image: "app.demoImage",
                     position: 1),
        NewsFeedModel(date: "01.01.2023",
                      title: "Schließung von DuMont Druck: ver.di ruft zum Protest auf",
                      link: "entry_1_url",
                      description: "Die geplante Schließung von \("DuMont Druck") und die damit verbundene Entlassung und Unsicherheit...",
                      image: "app.demoImage2",
                     position: 2),
        NewsFeedModel(date: "01.01.2023",
                      title: "Hier engagieren wir uns für Sie",
                      link: "entry_1_url",
                      description: "Die geplante Schließung von \("DuMont Druck") und die damit verbundene Entlassung und Unsicherheit...",
                      image: "app.demoImage",
                     position: 3),
        NewsFeedModel(date: "01.01.2023",
                      title: "Schließung von DuMont Druck: ver.di ruft zum Protest auf",
                      link: "entry_1_url",
                      description: "Die geplante Schließung von \("DuMont Druck") und die damit verbundene Entlassung und Unsicherheit...",
                      image: "app.demoImage2",
                     position: 4),
        NewsFeedModel(date: "01.01.2023",
                      title: "Hier engagieren wir uns für Sie",
                      link: "entry_1_url",
                      description: "Die geplante Schließung von \("DuMont Druck") und die damit verbundene Entlassung und Unsicherheit...",
                      image: "app.demoImage",
                     position: 5)
    ]
    
    static var keyWindow: UIWindow? {
        return UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.last
    }
}

//MARK: - APIError
enum APIError: Error {
    case badRequest(mesaage: String)
    case decodingError
    case invalidURL(urlStr: String)
}

extension APIError: CustomStringConvertible {
    var description: String {
        switch self {
        case .badRequest(let mesaage):
            return mesaage
        case .decodingError:
            return "Data could not be decodable."
        case .invalidURL(let urlStr):
            return "\(urlStr) is invalid url."
        }
    }
}

//Mark:- Constant
let timeOut = 10

//Mark:- WebURL
let moreViewLink = "https://yekta-it.de//"
let Meine_ver_diLink = "http://www.yekta-it.de/"
let ver_di_IKT_NRW = "http://www.yekta-it.de/"
let become_member = "http://www.yekta-it.de/"
let imprint = "http://www.yekta-it.de/"
let data_protection = "http://www.yekta-it.de/"
let facebookURL = "fb://profile/100064624933972"
let facebookAppStoreURL = "https://apps.apple.com/app/facebook/id284882215"
let twitterURL =  "https://twitter.com/_verdi"
let twitterAppStoreURL = "https://apps.apple.com/app/twitter/id333903271"
let instagramURL = "instagram://user?username=wirsindverdi"
let instagramAppstoreURL = "https://apps.apple.com/app/instagram/id389801252"

//MARK: - Padding margins
enum PaddingType {
    case vary_small
    case small
    case normal
    case medium
    case large
    case very_large
    
    var value: CGFloat {
        switch self {
        case .small: return 8
        case .medium: return 24
        case .large: return 32
        case .vary_small: return 4
        case .normal: return 16
        case .very_large: return 64
        }
    }
}

enum FrameType{
    case very_small
    case small
    case large
    case very_large
    case normal
    case medium
    case textFieldHeight
    case tabBarHeight
    
    var value: CGFloat{
        switch self{
            
        case .very_small: return 10
        case .small: return 24
        case .large: return 300
        case .very_large: return 550
        case .normal: return 80
        case .medium: return 40
        case .textFieldHeight: return 56
        case .tabBarHeight: return 108
        }
    }
}

enum StackSpacing: CGFloat{
    case small = 8
    case medium = 16
    case large = 24
}

enum FieldType: String {
    case company
    case location
    case name
    case email
    case subject
}
