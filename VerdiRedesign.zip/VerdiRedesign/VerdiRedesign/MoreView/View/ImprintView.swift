//
//  ImprintView.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import SwiftUI

struct ImprintView: View {
    //MARK: - Properties
    @Environment(\.presentationMode) var presentationMode
    let data: ListModel
    @Environment(\.openURL) var openURL
    //MARK: - Life cycle
    
    //MARK: - Body
    
    var body: some View {
        ZStack {
            Color.appTheme
                .ignoresSafeArea()
            
            VStack{
                navTitle
                
                textBlock
                
                Spacer()
            }
            .edgesIgnoringSafeArea(.top)
        }
        .navigationBarHidden(true)
    }
    
    //MARK: - Functions
    
    private var navTitle: some View{
        Color.appTabBg
            .frame(height: 156.asDeviceHeight)
            .frame(maxWidth: .infinity, alignment: .top)
            .overlay(alignment: .bottomLeading){
                VStack(alignment: .leading, spacing: 16){
                    HStack{
                        Image(systemName: "arrow.left")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(.appNavTitle)
                            .customFrame(width: .small, height: .small)
                            .onTapGesture {
                                self.presentationMode.wrappedValue.dismiss()
                            }
                        Spacer()
                    }
                    
                    Text(LocalizedStringKey(data.title ?? ""))
                        .font(.manrope(24, .semibold))
                        .foregroundColor(.appNavTitle)
                }
                .padding(.leading, .normal)
                .padding(.bottom, .medium)
            }
    }
    
    private var textBlock: some View{
        VStack(spacing: 18){
            Text(LocalizedStringKey(data.description1 ?? ""))
            .font(.manrope(14))
            .foregroundColor(.appNavTitle)
            .lineSpacing(5)
            
            if data.description2 != nil{
                Text(LocalizedStringKey(data.description2 ?? ""))
                    .font(.manrope(14))
                    .foregroundColor(.appNavTitle)
                    .lineSpacing(5)
            }
            
            if data.webLink != nil{
                HStack{
                    Text("Yekta IT GmbH")
                        .font(.manrope(14))
                        .underline()
                        .foregroundColor(.blue)
                    
                    Spacer()
                    
                    Image.appIconVector
                        .frame(width: 24, height: 24)
                        .onTapGesture {
                            if let url = URL(string: data.link ?? ""){
                                openURL(url)
                            }
                        }
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.appNewsCellBg)
        )
        .padding(.all, .normal)
    }
}

struct ImprintView_Previews: PreviewProvider {
    static var previews: some View {
        ImprintView(data: data[2])
    }
}


