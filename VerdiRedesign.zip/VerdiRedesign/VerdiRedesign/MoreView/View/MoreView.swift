//
//  MoreView.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import SwiftUI

struct MoreView: View {
    //MARK: - Properties
    @State var generalData = data
    @State var legalData = legalDataToDisplay
    @Environment(\.openURL) var openURL
    //MARK: - Life cycle
    
    //MARK: - Body
    var body: some View {
        NavigationView{
            ZStack {
                Color.appTheme
                    .ignoresSafeArea()
                
                VStack {
                    Color.appTabBg
                        .customFrame(height: .tabBarHeight)
                        .frame(maxWidth: .infinity, alignment: .top)
                    
                    Spacer()
                }
                .ignoresSafeArea()
                
                VStack{
                    navTitle
                    
                    MoreListView(listArr: generalData, title: "genaral")
                    
                    MoreListView(listArr: legalData, title: "Legal")
                    
                    Spacer()
                }
                .navigationBarHidden(true)
            }
        }
    }
    
    private var navTitle: some View{
        HStack(alignment: .bottom){
            Text(LocalizedStringKey("more"))
                .font(.manrope(24, .bold))
                .foregroundColor(.appNavTitle)
                .foregroundColor(.appNavTitle)
                .frame(alignment: .bottom)
                .padding(.vertical)
            
            Spacer()
        }
        .padding(.horizontal, .normal)
    }
    
    @ViewBuilder
    func MoreListView(listArr: [ListModel], title: String) -> some View{
        VStack(alignment: .leading, spacing: 0){
            Text(LocalizedStringKey(title))
                .font(.manrope(14, .semibold))
                .foregroundColor(.appNavTitle)
                .padding(.bottom, .small)
            
            VStack(spacing: 16) {
                ForEach(listArr, id:\.self){ data in
                    if let _ = data.link{
                        MoreListRow(data: data)
                    }else{
                        NavigationLink {
                            ImprintView(data: data)
                        } label: {
                            MoreListRow(data: data)
                        }
                    }
                }
            }
            .padding(.all, .normal)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.appNewsCellBg)
            )
        }
        .padding(.all, .normal)
    }
    
    @ViewBuilder
    func MoreListRow(data: ListModel) -> some View {
        HStack(spacing: 24){
            if let imageName = data.image{
                Image(imageName)
                    .customFrame(width: .small, height: .small)
            }else{
                Image(systemName: data.systemImage ?? "")
                    .resizable()
                    .customFrame(width: .small, height: .small)
                    .foregroundColor(.appGlobBG)
            }
            
            Text(LocalizedStringKey(data.title ?? ""))
                .foregroundColor(.appNavTitle)
                .font(.manrope(14, .semibold))
            
            Spacer()
            
            if let link = data.link{
                Image.appIconVector
                    .frame(width: 18, height: 18)
                    .onTapGesture {
                        if let url = URL(string: link){
                            openURL(url)
                        }
                    }
            }
        }
        .customFrame(height: .medium)
    }
    //MARK: - Functions
}

struct MoreView_Previews: PreviewProvider {
    static var previews: some View {
        MoreView()
    }
}
