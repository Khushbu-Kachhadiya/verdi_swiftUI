//
//  ListModel.swift
//  News Cenk
//
//  Created by APPLE on 22/12/23.
//

import Foundation

struct ListModel: Identifiable, Hashable{
    var id: Int
    var title: String?
    var systemImage: String?
    var image: String?
    var link: String?
    var description1: String?
    var description2: String?
    var webLink: String?
}


let data = [
    ListModel(id: 1, title: "My_ver.di", systemImage: "globe", link: "http://www.yekta-it.de/"),
    ListModel(id: 2, title: "ver.di_IKT_NRW", systemImage: "globe", link: "http://www.yekta-it.de/"),
    ListModel(id: 3, title: "become_member", image: "app.Icon.person", link: "http://www.yekta-it.de/"),
    ListModel(id: 4, title: "Tec_implementation", image: "app.Icon.mobile",
              description1: "Tec_implementation_discription",
              webLink: "sda")
]


let legalDataToDisplay = [
    ListModel(id: 1, title: "imprint", image: "app.Icon.pixelarticons", link: "http://www.yekta-it.de/"),
    ListModel(id: 2, title: "data_protection", image: "app.Icon.shield", link: "http://www.yekta-it.de/")
]
