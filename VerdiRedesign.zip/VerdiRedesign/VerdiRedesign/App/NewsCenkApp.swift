//
//  SwiftUIBoilerPlate.swift
//  SwiftUIDemo
//
//  Created by iOS Developer on 11/12/23.
//

import SwiftUI

@main
struct NewsCenkApp: App {
    //MARK: - Properties
    @UIApplicationDelegateAdaptor(Appdelegate.self) var delegate
    @StateObject private var rootManager = RootManager()
    
    //MARK: - LifeCycle
    var body: some Scene {
        WindowGroup {
            Group {
                switch rootManager.currentRoot {
                case .onboarding: OnboardingView()
                case .home: HomeView()
                case .tabBar: CustomTabbarScreenView()
                case .imprint(let data): TechnicalImplementationView(data: data)
                }
            }
            .environmentObject(rootManager)
        }
    }
    
    //MARK: - Body
    
    //MARK: - Functions
}
